### 🚀 Project Documentation: Smart Auto-Backup System (Cron Jobs Focused)
Level: Intermediate
Tech Stack: Node.js, Express, MongoDB, node-cron


# 📌 1. Objective

Build a system that automates file backups using cron jobs.

Users can configure how often they want their data backed up, and the system will:
• Automatically create backups at scheduled times
• Store backup files
• Log backup history
• Allow users to restore or download backups
• Provide fail-safety and error tracking

This project focuses strongly on cron jobs + scheduling logic.


# 📌 2. Core Features

✅ 2.1 User Backup Preferences

Each user can set:
• Backup frequency:
    • hourly
    • daily
    • weekly
    • custom cron expression

• Backup target: folder / file path
• Is backup active?


✅ 2.2 Cron-Based Backup Execution
Using node-cron, the system automatically:
• Reads active user schedules
• Runs backup jobs based on their cron expression
• Creates backup files (e.g., ZIP)
• Saves backups to /backups/ folder
• Logs success / failure

✅ 2.3 Backup File Creation
Backup system should:
• Compress the selected folder/file
• Save it with timestamp → backup_2025-12-09_12-20.zip
• Validate file exists
• Check size
• Delete old backups automatically using MongoDB TTL Index
• TTL index automatically removes backup logs after X days
• cleanup cron will delete ZIP files that no longer have a DB entry

✅ 2.4 Backup Logs & History
For each backup, store:
• userId
• backupTime
• status (success / failed)
• backupFilePath
• errorMessage (optional)

✅ 2.5 Manual Controls
API Endpoints:
• Start backup manually
• List backup history
• Download backup file
• Delete backup


✅ 2.6 Auto-Deletion of Old Backups (Option B)
Using MongoDB TTL indexes:
• A TTL index will auto-delete backup logs after X days
• A cleanup cron runs every hour to remove ZIP files that no longer have a DB entry
• No need to manually delete backups

example TTL index:
createdAt: { expires: 604800 }  // 7 days



# 📌 3. API Endpoints
🔹 POST /api/backup/settings

Create or update backup settings

Body:
{
  "userId": "123",
  "frequency": "daily",
  "cronExpression": null,
  "pathToBackup": "/user/files/project"
}


🔹 POST /api/backup/run
Trigger manual backup

🔹 GET /api/backup/history/:userId
List backup logs for user


🔹 GET /api/backup/download/:backupId
Download backup ZIP


🔹 DELETE /api/backup/:backupId
Delete backup file + remove record


# 📌 4. Cron Job Logic
We will use node-cron.

🔧 Cron Engine Rules

Every minute, a “master cron job” will:

1.. Fetch all users with active schedules

2.. For each user:
• Convert their frequency into cron format
• Check if it’s time to create backup
• Create a backup job


New Cron Job: cleanupCron.js

Runs every hour:
• Read all ZIP files in /backups
• Check if backupLog exists for each file
• If not → delete the orphaned ZIP file

This keeps storage clean.

This allows:
✔ Multiple users
✔ Different frequencies
✔ Custom schedules



# 📌 5. Backup Workflow
User sets schedule → Cron engine runs → 
Check if backup due → Start backup → 
Compress folder → Save ZIP → 
Store backup log → Send response


# 📌 6. Data Models (MongoDB)

🟦 BackupSettings Model
{
  userId: String,
  frequency: String,     // daily / weekly / hourly / custom
  cronExpression: String,
  pathToBackup: String,
  isActive: Boolean,
  updatedAt: Date
}


🟩 BackupLog Model
{
  userId: String,
  status: "success" | "failed",
  backupFilePath: String,
  errorMessage: String,
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 604800  // 7 days in seconds
   }
}

# Note: 
This TTL index ensures MongoDB automatically deletes logs older than 7 days.
Deleting the ZIP file will be handled by a cleanup cron script.


# 📌 7. Folder Structure
project/
│
├── src/
│   ├── config/
│   │   └── db.js
│   ├── cron/
│   │   ├── backupScheduler.js
│   │   └── cleanupCron.js 
│   ├── controllers/
│   │   ├── backupController.js
│   ├── models/
│   │   ├── BackupSettings.js
│   │   └── BackupLog.js
│   ├── services/
│   │   └── backupService.js
│   ├── utils/
│   │   └── zipHelper.js
│   └── server.js
│
├── backups/   <-- all .zip backups stored here
├── package.json
└── README.md




# 📌 8. Dependencies
npm install express mongoose node-cron archiver fs-extra 

• express → API layer
• mongoose → MongoDB ORM
• node-cron → scheduling
• archiver → compress backup files
• fs-extra → safe file & folder deletion


# 📌 9. Project Flowchart
User sets frequency
        ↓
Save in DB
        ↓
Cron Engine reads settings every minute
        ↓
If backup is due → run backup
        ↓
Compress files → save ZIP
        ↓
Log success / failure



# 📌 10. Future Enhancements
• Keep only last 5 backups
• Keep weekly/monthly snapshots
• Different TTL per user