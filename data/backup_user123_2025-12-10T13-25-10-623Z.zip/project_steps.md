# Steps for creating the project -

Step One - Install all necesssary packages and create project structure
Step Two - Create server.js file in src folder and crete db.js file in config folder for setup the mongoDB database

Step Three - Create the BackupSetting.js and BackupLog.js file in the config folder, BackupLog file store the log of zip file in DB and BackupSettings use that which file or data need to backup and which time

Step Four - Create the zipHelper.js file in the utils folder so this file help us to create zip files
Step Five - Create the backupService.js file in the service folder for the responsible for zip file creation

Step Six - Create the test folder in root and in the fodler create a file for testing